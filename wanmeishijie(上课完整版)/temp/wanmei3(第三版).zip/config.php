<?php
	define( "DB_HOST", "localhost" );
	define( "DB_USER", "root" );
	define( "DB_PWD", "root" );
	define( "DB_NAME", "wanmei2" );
?>