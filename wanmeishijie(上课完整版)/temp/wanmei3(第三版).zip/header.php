<div id="menu">
	<div class="layout">
		<a href="./" class="logo">完美世界</a>
		<span class="log_line"></span>
		<h4><span class="icon tit"></span></h4>
		<ul>
			<li>
			<a href="./" class="on">首页</a>
		<?php
			$nav_list = get_cate_list( $pid = 0, $result, $level = 0, $type = array( 1,2,4 ) );
			// print_r( $nav_list );
			if ( !empty( $nav_list ) ) {
				foreach ( $nav_list as $nav ) {
					?>
					<a href="<?php echo $nav['original_url']; ?>"><?php echo $nav['cate_name']; ?></a>
					<?php
				}
			}
		?>	
			</li>
		</ul>
		<div class="clear"></div>
	</div>
</div>
<?php
	$file_path = str_replace( strrchr( $_SERVER['SCRIPT_NAME'], '/' ), '', $_SERVER['SCRIPT_NAME'] );
	if ( isset( $_SERVER['SCRIPT_NAME'] ) ) {
		$cur_file = str_replace( '/', '', strrchr( $_SERVER['SCRIPT_NAME'], '/' ) );

		?>
		<script>

		$(function(){
			$("#menu li a").each(function(){				
				if ( /<?php echo $cur_file; ?>/.test( $(this).attr( "href" ) ) ) {							
					$(this).attr( "class", "on" );
				} else {
					$(this).attr( "class", "" );
				}
			});
		});
		</script>
		<?php
	}
?>