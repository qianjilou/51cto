<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>完美世界</title>
	<link rel="stylesheet" href="./css/style.css" />
    <link rel="stylesheet" href="./css/css.css" />
	<script type="text/javascript" src="./js/common.js"></script>
	<script type="text/javascript" src="./js/index.js"></script>	
</head>
<body>
	<?php
  require( "init.php" );
  require( "header.php" );
  ?>
  <?php
    $req_url = $_SERVER['REQUEST_URI'];
    $tab_id = !empty( $_REQUEST['tab_id'] ) ? intval( $_REQUEST['tab_id'] ) : $_REQUEST['cat_id'];
    $cur_tab_id = "&tab_id=$tab_id";   
  ?>
<div id="wrap">
 <div class="news_top">
  <?php
    $curpage = !empty( $_REQUEST['p'] ) ? intval( $_REQUEST['p'] ) : 1;
    $perpage = 3;
    if ( !empty( $tab_id ) ) {
       $cat_detail = get_cat_detail( $tab_id );
       echo $cat_detail['cate_name'];
    }
  ?>
 </div>
 <div class="news_title">您所在的位置：首页 > <?php if ( !empty( $cat_detail ) ) { echo $cat_detail['cate_name']; } ?></div>
 <div class="news_content">
   <div class="news_content_left_title">
     <ul>
        <?php
        $c_id = is_int( $_REQUEST['cat_id'] ) ? intval( $_REQUEST['cat_id'] ) : 2;
        $req_url = preg_replace( '/&p=\d+/', '', $req_url );
        $req_url = preg_replace( '/&tab_id=\d+/', '', $req_url );
          if ( !empty( $c_id ) ) {
            $son_cats = get_son_cates( $c_id );
            foreach ( $son_cats as $cat ) {
              ?>
              <li <?php echo ( $cat['cat_id'] == $tab_id ) ? ( 'class="tab_selected"' ) : ""; ?> ><a href="news.php?cat_id=<?php echo $c_id; ?>&tab_id=<?php echo $cat['cat_id']; ?>"><?php echo $cat['cate_name'] ?></a></li>             
              <?php
            }
          }          
        ?>       
     </ul>
   </div>

	<?php
		if ( !empty( $_REQUEST['id'] ) ) {
			$arc = get_arc_byid( $_REQUEST['id'] );
		}		
	?>

	<?php
		if ( !empty( $arc ) ) {
			?>
			<div class="news_content_left_bg">
			    <div class="news_details_title">
			    <?php echo $arc['title']; ?>
			    <br /><span class="news_font03"><?php echo $arc['author']; ?> <?php echo $arc['publish_time']; ?>
			    </span>
	       		</div>
			    <?php echo htmlspecialchars_decode( $arc['content'], ENT_QUOTES ); ?>
			    <div style="margin-top:20px;height:60px;">
			    	<?php
			    		if ( !empty( $_REQUEST['id'] ) ) {
		    				$sql = "SELECT * FROM wm_article WHERE article_id < {$_REQUEST['id']} AND cat_id = {$_REQUEST['cat_id']} ORDER BY article_id DESC LIMIT 1";		    				
		    				$rs = mysql_query( $sql );
		    				$prev_arc = mysql_fetch_assoc( $rs );
		    				if ( !empty( $prev_arc ) ) {
		    					?>
		    					<span>
		    					<a href="<?php 
		    						$req_url = $_SERVER['REQUEST_URI'];
		    						$req_url = preg_replace( '/\?id=\d+/', "?id={$prev_arc['article_id']}", $req_url );	
		    						echo $req_url;
		    					?>">
		    					<?php echo '&lt;&lt;' . htmlspecialchars_decode( $prev_arc['title'], ENT_QUOTES ); ?>
		    					</a>
		    					</span>
		    					<?php
		    				}
			    		}			    		
			    	?>

			    	<?php
			    		if ( !empty( $_REQUEST['id'] ) ) {
		    				$sql = "SELECT * FROM wm_article WHERE article_id > {$_REQUEST['id']} AND cat_id = {$_REQUEST['cat_id']} ORDER BY article_id ASC LIMIT 1";		    						    				
		    				$rs = mysql_query( $sql );
		    				$next_arc = mysql_fetch_assoc( $rs );
		    				if ( !empty( $next_arc ) ) {
		    					?>
		    					<span style="margin-left:50px;">
		    					<a href="<?php 
		    						$req_url = $_SERVER['REQUEST_URI'];		    						
		    						$req_url = preg_replace( '/\?id=\d+/', "?id={$next_arc['article_id']}", $req_url );		    						
		    						echo $req_url;
		    					?>">
		    					<?php echo htmlspecialchars( $next_arc['title'], ENT_QUOTES ) . '&gt;&gt;'; ?>
		    					</a>
		    					</span>
		    					<?php
		    				}
			    		}			    		
			    	?>
			    </div>
	      </div>
			<?php
		}
	?>
   
   
   
   
   
   
   
   <div class="news_content_right"><img src="images/news_right.png" width="220" height="136"></div>
   <div style=" clear:both;"></div>
 </div>
 <div style=" clear:both;"></div>
</div>
<div class="bottom"><div class="max"><ul class="content"><li><div class="tit01"><span>公司</span></div><p><a href="http://www.wanmei.com/enterprise/company.htm">公司简介</a></p><p><a href="http://hr.wanmei.com" target="_blank">招聘信息</a></p><p><a href="http://www.wanmei.com/enterprise/aboutme.htm">联系我们</a></p><p><a href="http://www.wanmei.com/enterprise/legal.htm">法律声明</a></p><p><a href="http://www.wanmei.com/enterprise/sitemap.htm">网站地图</a></p></li><li><div class="tit01"><span>账号</span></div><p><a href="http://passport.wanmei.com/jsp/member/register.jsp">注册通行证账号</a></p><p><a href="http://passport.wanmei.com/">账号安全</a></p><p><a href="http://passport.wanmei.com/jsp/indulge/index.jsp">防沉迷登记</a></p><p><a href="http://passport.wanmei.com/jsp/member/password.jsp">修改密码</a></p></li><li><div class="tit01"><span>充值</span></div><p><a href="http://pay.wanmei.com">充值中心</a></p><p><a href="http://www.wanmei.com/pay/goukazhinan.shtml">购卡指南</a></p><p><a href="http://www.wanmei.com/pay/faq_other.shtml">充值问题</a></p></li><li><div class="tit01"><span>游戏</span></div><p><a href="http://www.arcgames.cn/">Arc游戏平台</a></p><p><a href="http://www.173.com/">Arc页游</a></p><p><a href="http://www.4games.com">海外4Games</a></p><p><a href="http://www.laohu.com">老虎游戏</a></p></li><li><div class="tit01"><span>服务</span></div><p><a href="http://vip.wanmei.com">特权VIP</a></p><p><a href="http://cs.wanmei.com">客服中心</a></p><p><a href="http://www.wanmei.com/jiazhang/">家长监护</a></p></li><li class="r"><div class="tit01"><span>商城</span></div><p><a href="http://shop.wanmei.com">完美商城</a></p><p><a href="http://wanmei.tmall.com">天猫旗舰店</a></p><p><a href="http://wanmeishijie.jd.com">京东旗舰店</a></p></li></ul><!--h5><a href="http://www.wanmei.com/enterprise/company.htm">公司介绍</a> | <a href="#">开发团队</a> | <a href="http://hr.wanmei.com" target="_blank">招聘信息</a> | <a href="aboutme.htm">联系我们</a> | <a href="proclaim.htm">法律声明</a> | <a href="map.htm">网站地图</a></h5--><h5 style="text-align:center; line-height:2;">京ICP证：050016号《网络文化经营许可证》编号：京网文[2011]0782-287号《网络视听许可证》编号：0110587 京公网安备110105019888号 <br>建议18岁以上的成年人游戏<br>完美世界（北京）网络技术有限公司 版权所有</h5><h5 style="text-align:center;"><a href="http://www.hd315.gov.cn/beian/view.asp?bianhao=010202005060700536" target="_blank"><img src="images/icp.gif" alt=""></a><a href="https://ss.knet.cn/verifyseal.dll?sn=2011011300100005061&amp;ct=df&amp;pa=011371" target="_blank"><img src="images/kexin.gif" alt=""></a><a href="http://www.bjwhzf.gov.cn/accuse.do" target="_blank"><img src="images/sc.gif" alt=""></a><a href="http://www.cogcpa.org/" target="_blank"><img src="images/bq.gif" alt=""></a><a href="http://www.wanmei.com/news_lvse.htm" target="_blank"><img src="images/lvse.gif" alt=""></a></h5><h6>京ICP证：050016号《网络文化经营许可证》<br>完美世界（北京）网络技术有限公司 版权所有</h6></div></div>	
</body>
</html>