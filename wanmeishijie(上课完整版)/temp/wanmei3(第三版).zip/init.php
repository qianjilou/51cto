<?php
	//加载数据库连接
	require( "db.php" );	
	require( "./lib/lib_common.php" );	
?>