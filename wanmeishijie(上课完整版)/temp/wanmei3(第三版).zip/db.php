<?php
	require( "./config.php" );
	session_start();
	$link = mysql_connect( DB_HOST, DB_USER, DB_PWD ) or die ( mysql_error() );
	mysql_select_db( DB_NAME );
	mysql_query( "set names utf8" );
?>