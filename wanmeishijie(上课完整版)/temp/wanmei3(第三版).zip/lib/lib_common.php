<?php
	function get_all_ads () {
		$sql = "SELECT * FROM wm_index_ads WHERE is_show = 1 ORDER BY sort_order ASC";
		$res = mysql_query( $sql );
		$ads = array();
		while ( $row = mysql_fetch_assoc( $res ) ) {
			$ads[] = $row;
		}
		return $ads;
	}
	/*
		$pid:父ID
		$result:所有分类
		$leve:返回分类的层数
		@param Array $type:返回分类的类型: 1:分类, 2:文章, 3:政策, 4:导航
	 */
	function get_cate_list ( $pid = 0, &$result = array(), $level = 0, $type = '' ) {
		
		$sql = "SELECT * FROM wm_category WHERE 1 = 1 AND pid = $pid";
		if ( !empty( $type ) ) {
			$s_t = '(' . implode( ',', $type ) . ')';
			$sql .= " AND type IN $s_t";
		}
		$rs = mysql_query( $sql );
		while ( $row = mysql_fetch_assoc( $rs ) ) {
			$result[] = $row;
			if ( $level != 0 ) {
				if ( $row )  {
					get_cate_list( $row['cat_id'], $result, $level, $type );
				}
			}			
		}
		return $result;
	}

	//首页特征游戏板块取出4张特张图片
	function get_feature_game () {
		$sql = "SELECT * FROM wm_category WHERE rec_type = 3 AND is_show = 1 ORDER BY sort_order ASC LIMIT 4";
		$res = mysql_query( $sql );
		$list = array();
		while ( $row = mysql_fetch_assoc( $res ) ) {
			$list[] = $row;
		}
		return $list;
	}

	//首页特征分类板块取出2张特征图片
	function get_thumb_game_img () {
		$sql = "SELECT * FROM wm_category WHERE rec_type = 4 AND is_show = 1 ORDER BY sort_order ASC LIMIT 2";
		$res = mysql_query( $sql );
		$list = array();
		while ( $row = mysql_fetch_assoc( $res ) ) {
			$list[] = $row;
		}
		return $list;
	}

	//取出对应分类下面的文章
	function get_articles_byid ( $cat_id, $cur_p = 1, $page_size = 3 ) {
		$sql = "SELECT * FROM wm_article WHERE 1 = 1 AND is_show = 1 AND cat_id = $cat_id ORDER BY sort_order ASC";
		if ( !empty( $cur_p ) ) {
			$sql .= " LIMIT " . ( $cur_p - 1 ) * $page_size . ',' . $page_size;
		}		
		$res = mysql_query( $sql );
		$list = array();
		while ( $row = mysql_fetch_assoc( $res ) ) {
			$list[] = $row;
		}
		return $list;
	}

	//取出分类的文章总数
	function get_all_articles ( $cat_id ) {
		$sql = "SELECT * FROM wm_article WHERE 1 = 1 AND is_show = 1 AND cat_id = $cat_id ";
		$res = mysql_query( $sql );		
		return mysql_num_rows( $res );
	}

	//根据分类提出子类
	function get_son_cates ( $cat_id ) {
		$sql = "SELECT * FROM wm_category WHERE pid = $cat_id AND is_show = 1 ORDER BY sort_order ASC";
		$res = mysql_query( $sql );
		$list = array();
		while ( $row = mysql_fetch_assoc( $res ) ) {
			$list[] = $row;
		}
		return $list;
	}

	function get_cat_detail ( $cat_id ) {
		$sql = "SELECT * FROM wm_category WHERE cat_id = $cat_id";
		$res = mysql_query( $sql );
		return mysql_fetch_assoc( $res );
	}

	
	function page ( $page_url, $total_nums, $cur_p, $page_size = 5 ) {

		$page_url .= (strpos($page_url, '?') === false) ? '?' : '&';
		$pages = ceil( $total_nums / $page_size );
		$s = '';
		for ( $index = 1; $index <= $pages; $index++ ) {
			if ( $index == $cur_p ) {
				$s .= '<a class="active" href="' . $page_url . 'p=' . $index . '">' . $index . '</a>';
			} else {
				$s .= '<a href="' . $page_url . 'p=' . $index . '">' . $index . '</a>';	
			}			
		}
		return $s;
	}

	//根据文章ID获取对应的文章
	function get_arc_byid ( $id ) {
		$sql = "SELECT * FROM wm_article WHERE article_id = $id";
		$res = mysql_query( $sql );
		return mysql_fetch_assoc( $res );
	}

	//面包屑导航
	function get_cate_path ( $cid, &$result = array() ) {
		$sql = "SELECT * FROM wm_category WHERE cat_id = $cid";
		$rs = mysql_query( $sql );
		$row = mysql_fetch_assoc( $rs );
		$result[] = $row;
		if ( $row['pid'] ) {
			get_cate_path( $row['pid'], $result );
		}
		return $result;
	}
	
	function display_cate_path( $cid ) {
		$cate_path = get_cate_path( $cid );
		krsort( $cate_path );
		$s = '';		
		foreach ( $cate_path as $key => $c_path ) {			
			$s .= "<a href='game.php?cid={$c_path['cat_id']}'>" . $c_path['cate_name'] . "</a>" . ' > ';
		}		
		return substr( $s, 0, strrpos( $s, ' > ' ) - strlen( $s ) );
	}

	//获取所有推荐到首页的文章
	function get_index_arcticles () {
		$sql = "SELECT * FROM wm_article WHERE rec_to_index = 1 AND is_show = 1 ORDER BY sort_order ASC LIMIT 4";
		$list = array();
		$res = mysql_query( $sql );
		while ( $row = mysql_fetch_assoc( $res ) ) {
			$list[] = $row;
		}
		return $list;
	}
?>