<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>管理员登录</title>
	<script type="text/javascript" src="../js/jquery.min.js"></script>
	<script type="text/javascript" src="../js/index.js"></script>	
	<link rel="stylesheet" href="./css/style.css" />
</head>
<body>
	<div class="layout">
		<div>
			<div id="tips"></div>	
			<form action="" method="post" id="user_form">
				<table class='tb w65 size28'>
					<tr>
						<th colspan="2" align="center">管理员登录</th>
					</tr>
					<tr>
						<th width="150">用户名:</th>
						<td align="left"><input type="text" name="user" id="user" class="text" size=16 /></td>
					</tr>
					<tr>
						<th width="150">密码:</th>
						<td align="left"><input type="password" name="pwd" id="pwd" class="text" size=16 /></td>
					</tr>
					<tr>
						<td colspan="2" align="center">							
							<input type="submit" name="login" id="login" value="登录" class="btn" />
						</td>
					</tr>
				</table>
			</form>
		</div>
	</div>
	<?php
		require( "./init.php" );

		// session登录验证
		// if ( !empty( $_SESSION['admin_user'] ) && !empty( $_SESSION['admin_password'] ) ) {
		// 	if ( login( $_SESSION['admin_user'], $_SESSION['admin_password'] ) ) {
		// 		header( "Location:leader_manage.php" );
		// 		exit;
		// 	}
		// }
		
		if ( isset( $_POST['login'] ) ) {
			$user = trim( $_POST['user'] );
			$pwd = trim( $_POST['pwd'] );
			if ( login( $user, $pwd ) ) {

				//设置cookie
				// setcookie( 'user', $user, time() + 3600 * 7 * 24 );
				// setcookie( 'password', $pwd, time() + 3600 * 7 * 24 );
				
				//设置session
				$_SESSION['admin_user'] = $user;
				$_SESSION['admin_password'] = $pwd;
				//延长session作用时间
				setcookie( session_name(), session_id(), time() + 3600 * 7 * 24 );

				header( "Location:./category_manage.php" );
			} else {
				echo "登录失败";
			}
		}
	?>
</body>
</html>