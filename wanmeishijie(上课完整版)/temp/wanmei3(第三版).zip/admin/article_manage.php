<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>文章管理</title>
	<link rel="stylesheet" href="./css/style.css" />
	<script type="text/javascript" src="../js/jquery.min.js"></script>
</head>
<body>
	<?php
		require( "init.php" );
		require( "admin_header.php" );
	?>
	<div class="layout">
		<div id="tips"></div>		
			<table class="tb w100">
				<tr>
					<th colspan="7">文章管理</th>
				</tr>
				<tr>
					<th>ID</th>
					<th>标题</th>
					<th>分类</th>
					<th>显示</th>
					<th>排序</th>
					<th>操作</th>
				</tr>
				<?php
					$all_arc_list = get_article_list();
					$file_path = str_replace( strrchr( $_SERVER['SCRIPT_NAME'], '/' ), '', 
						$_SERVER['SCRIPT_NAME'] );
					$file_path = str_replace( strrchr( $file_path, '/' ), '', $file_path );
					if ( !empty( $all_arc_list ) ) {
						foreach ( $all_arc_list as $arc ) {
							?>
							<tr>
								<td><?php echo $arc['article_id']; ?></td>
								<td><?php echo $arc['title']; ?></td>
								<td><?php echo $arc['cate_name']; ?></td>
								<td><?php echo ( $arc['is_show'] > 0 ) ? "是" : "否"; ?></td>
								<td><?php echo $arc['sort_order']; ?></td>
								<td>
									<a href="article_add.php">添加</a>
									<a href="article_edit.php?id=<?php echo $arc['article_id']; ?>">编辑</a>
									<a href="article_manage.php?act=del&id=<?php echo $arc['article_id']; ?>">删除</a>
								</td>
							</tr>
							<?php
						}
					}
				?>
			</table>		
	</div>		
</body>
</html>