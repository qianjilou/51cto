<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>分类管理</title>
	<link rel="stylesheet" href="./css/style.css" />
	<script type="text/javascript" src="../js/jquery.min.js"></script>
</head>
<body>
	<?php
		require( "init.php" );
		require( "admin_header.php" );
	?>
	<div class="layout">
		<?php
			$cate_list = get_cate_list( $pid = 0, $result, $space = 0, $type = 1 );
			// print_r( $cate_list );
			if ( !empty( $cate_list ) ) {
				echo "<ul>";
				foreach ( $cate_list as $son1 ) {
					echo "<li class='level_one'>{$son1['cate_name']}<span class='oper'><a href='category_edit.php?cat_id={$son1['cat_id']}'>编辑</a></span><ul>";
					if ( is_array( $son1['son'] ) ) {
						foreach ( $son1['son'] as $son2 ) {
							echo "<li class='level_two'>{$son2['cate_name']}<span class='oper'><a href='category_edit.php?cat_id={$son2['cat_id']}'>编辑</a></span><ul>";
							if ( is_array( $son2['son'] ) ) {
								foreach ( $son2['son'] as $son3 ) {
									?>
									<li class='level_three'>
									<?php echo $son3['cate_name']; ?>
									<span class='oper'>
										<a href='category_add.php'>添加</a>
										<a href="category_edit.php?cat_id=
										<?php echo $son3['cat_id']; ?>
										">编辑</a>
										<a href="?act=del&id=
										<?php echo $son3['cat_id']; ?>
										">删除</a>
									</span>
									</li>
									<?php									
								}
							}
							echo "</ul></li>";
						}
					}
					echo "</ul></li>";
				}
				echo "</ul>";
			}
		?>
	</div>	
</body>
</html>