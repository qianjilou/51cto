<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>分类编辑</title>
	<link rel="stylesheet" href="./css/style.css" />
	<script type="text/javascript" src="../js/jquery.min.js"></script>
</head>
<body>
	<?php
		require( "init.php" );
		require( "admin_header.php" );
	?>
	
	<?php
		if ( isset( $_POST['submit'] ) ) {

			$cat_name = trim( $_POST['cat_name'] );
			// if ( has_category( $cat_name ) ) {
			// 	echo "<script>alert('分类名已经存在!!!');</script>";
			// 	die();
			// }
			$pid = $_POST['cate_list'];
			// if ( empty( $cat_name ) ) {
			// 	echo "<script>alert('分类名没有填写!!!');</script>";
			// 	die();
			// }
			$keywords= trim( $_POST['keywords'] );
			$desc = trim( $_POST['desc'] );
			$sort = $_POST['sort'];
			$is_show = $_POST['is_show'];
			$url = $_POST['url'];
			$type = $_POST['type'][0];
			$rec_type = $_POST['rec_type'][0];
			$feature_name = htmlspecialchars( trim( $_POST['feature_name'] ), ENT_QUOTES );


			if ( !empty( $_FILES['img_upload']['tmp_name'] ) ) {
				if ( $_FILES['img_upload']['error'] > 0 ) {
					switch ( $_FILES['img_upload']['error'] ) {
						case 1:
							die( "上传的文件超过了 php.ini 中 upload_max_filesize 选项限制的值" );
						case 2:
							die( "上传文件的大小超过了 HTML 表单中 MAX_FILE_SIZE 选项指定的值" );
						case 3:
							die( "文件只有部分被上传" );
						case 4:
							die( "没有文件被上传" );
						default:
							die( "未知错误" );
					}
				}

				$root_path = str_replace( '\\', '/', dirname( __FILE__ ) );
				$root_path = str_replace( strrchr( $root_path, '/' ), '', $root_path );			
				$upload_dir = $root_path . '/upload/';
				if ( upload_file( $_FILES['img_upload']['tmp_name'],
					$_FILES['img_upload']['name'], $upload_dir  ) ) {

					$file_name = $upload_dir . $_FILES['img_upload']['name'];
					$db_file_name = '/upload/' . $_FILES['img_upload']['name'];
					$dst_img = explode( ".", $_FILES['img_upload']['name'] );
					$dst_img_center = $upload_dir . $dst_img[0] . '_center.' . $dst_img[1];
					$db_img_center = '/upload/' . $dst_img[0] . '_center.' . $dst_img[1];
					$dst_img_thumb = $upload_dir . $dst_img[0] . '_thumb.' . $dst_img[1];
					$db_img_thumb = '/upload/' . $dst_img[0] . '_thumb.' . $dst_img[1];
					list( $width, $height, $type, $attr ) = getimagesize( $file_name );
					zoom_img( $file_name, $dst_img_center, $width / 2, $height / 2  );
					zoom_img( $file_name, $dst_img_thumb, $width / 4, $height / 4  );
					?>
					<script>
					$( "#tips" ).html( "<span class='success'>文件上传成功</span>" );
					</script>
					<?php
				} else {
					?>
					<script>
					$( "#tips" ).html( "<span class='error'>文件上传失败!</span>" );
					</script>
					<?php
				}
			}
			
			$cate = get_cate_byid( $_REQUEST['cat_id'] );

			$db_file_name = !empty( $db_file_name ) ? $db_file_name : $cate['img_original'];
			$db_img_thumb = !empty( $db_img_thumb ) ? $db_img_thumb : $cate['img_thumb'];
			$db_img_center = !empty( $db_img_center ) ? $db_img_center : $cate['img_center'];

			$sql = "UPDATE wm_category SET cate_name = '$cat_name',
			keywords = '$keywords', `desc` = '$desc', pid = '$pid', sort_order = '$sort',
			is_show = '$is_show', img_center = '$db_img_center', img_thumb = '$db_img_thumb',
			img_original = '$db_file_name', original_url = '$url', thumb_url = '$url', center_url = '$url',
			type = '$type', rec_type = '$rec_type', feature_name = '$feature_name' WHERE cat_id = {$_REQUEST['cat_id']}";

			$res = mysql_query( $sql ) or die ( mysql_error() );
			echo "<script>alert('分类更新成功!!!');</script>";			
		}
	?>

	<?php
		$root_path = str_replace( '\\', '/', $_SERVER['SCRIPT_NAME'] );
        $root_path = str_replace( strrchr( $root_path, '/' ), '', $root_path );
        $root_path = str_replace( strrchr( $root_path, '/' ), '', $root_path );
		if ( !empty( $_REQUEST['cat_id'] ) ) {
			$cate = get_cate_byid( $_REQUEST['cat_id'] );
		}		
	?>
	<div class="layout">
		<div id="tips"></div>
		<form action="" method="post" enctype="multipart/form-data">
			<table class="tb w100">
				<tr>
					<th colspan="2">分类编辑</th>
				</tr>
				<tr>
					<th>分类名称:</th>
					<td><input type="text" name="cat_name" id="cat_name" 
					value="<?php
						if ( !empty( $cate ) ) {
							echo $cate['cate_name'];
						}
					?>" /></td>
				</tr>
				<tr>
					<th>分类URL:</th>
					<td><input type="text" name="cat_url"
					 value="<?php
					 if ( !empty( $cate ) ) {
					 	echo $cate['cat_url'];
					 }
					 ?>" /></td>
				</tr>
				<tr>
					<th>特征标题:</th>
					<td>
						<input type="text" name="feature_name" 
						value="<?php if ( !empty( $cate ) ) {
								echo $cate['feature_name'];
							} ?>" size=80 />
					</td>
				</tr>
				<tr>
					<th>分类列表:</th>
					<td>
						<?php 
							if ( !empty( $cate ) ) {
								echo display_cate( 0, $cate['pid'] );
							}							
				 		?>						
					</td>
				</tr>
				<tr>
					<th>关键词:</th>
					<td>
						<textarea name="keywords" id="keywords" 
						cols="50" rows="3"><?php if ( !empty( $cate ) ) { echo $cate['keywords']; } ?>
						</textarea>
					</td>
				</tr>
				<tr>
					<th>描述:</th>
					<td>
						<textarea name="desc" id="desc" cols="50" rows="10"><?php if( !empty( $cate ) ) { echo $cate['desc']; } ?></textarea>
					</td>
				</tr>
				<tr>
					<th>排序:</th>
					<td>
						<input type="text" name="sort" id="sort" 
						value="<?php
							if ( !empty( $cate ) ) {
								echo $cate['sort_order'];
							}
						?>" />
					</td>
				</tr>
				<tr>
					<th>是否显示:</th>
					<td>
						<?php
							if ( !empty( $cate ) ) {
								?>
								<input type="radio" name="is_show" value=1 <?php if ( $cate['is_show'] == 1 ) { ?> checked <?php } ?> />是
								<input type="radio" name="is_show" value=0 <?php if ( $cate['is_show'] == 0 ) { ?> checked <?php } ?> />否
								<?php
							} else {
								?>
								<input type="radio" name="is_show" value=1 checked />是
								<input type="radio" name="is_show" value=0 />否
								<?php
							}
						?>
						
					</td>
				</tr>
				<tr>
					<th>中图:</th>
					<td>
						<?php
							if ( !empty( $cate['img_center'] ) ) {
								?>
								<img src="<?php echo $root_path . $cate['img_center']; ?>" width=215 height=120 />
								<?php
							}
						?>
					</td>
				</tr>
				<tr>
					<th>缩略图</th>
					<td>
						<?php
							if ( !empty( $cate['img_thumb'] ) ) {
								?>
								<img src="<?php echo $root_path . $cate['img_thumb']; ?>" width=190 height=95 />
								<?php
							}
						?>
					</td>
				</tr>
				<tr>
					<th>上传图片:</th>
					<td>
						<input type="file" name="img_upload" />
					</td>
				</tr>
				<tr>
					<th>链接:</th>
					<td>						
						<input type="text" name="url"
						value="<?php
						if ( !empty( $cate['original_url'] ) ) {
							echo $cate['original_url'];
						}
						?>" />
					</td>
				</tr>
				<tr>
					<th>分类类型:</th>
					<td>
						<?php
							if ( !empty( $cate ) ) {
								?>
								<input type="radio" name="type[]" value="1" <?php echo ( !empty( $cate['type'] ) && $cate['type'] == 1 ) ? "checked" : ""; ?> />分类
								<input type="radio" name="type[]" value="2" <?php echo ( !empty( $cate['type'] ) && $cate['type'] == 2 ) ? "checked" : ""; ?> />文章
								<input type="radio" name="type[]" value="3" <?php echo ( !empty( $cate['type'] ) && $cate['type'] == 3 ) ? "checked" : ""; ?> />政策
								<input type="radio" name="type[]" value="4" <?php echo ( !empty( $cate['type'] ) && $cate['type'] == 4 ) ? "checked" : ""; ?> />导航栏
								<?php
							}
						?>						
					</td>
				</tr>
				<tr>
					<th>推荐:</th>
					<td>
						<?php
							if ( !empty( $cate ) ) {
								?>
								<input type="radio" name="rec_type[]" value="0" <?php echo ( isset( $cate['rec_type'] ) && $cate['rec_type'] == 0 ) ? "checked" : ""; ?> />无
								<input type="radio" name="rec_type[]" value="1" <?php echo ( isset( $cate['rec_type'] ) && $cate['rec_type'] == 1 ) ? "checked" : ""; ?> />热门
								<input type="radio" name="rec_type[]" value="2" <?php echo ( isset( $cate['rec_type'] ) && $cate['rec_type'] == 2 ) ? "checked" : ""; ?> />最新
								<input type="radio" name="rec_type[]" value="3" <?php echo ( isset( $cate['rec_type'] ) && $cate['rec_type'] == 3 ) ? "checked" : ""; ?> />首页推荐栏
								<input type="radio" name="rec_type[]" value="4" <?php echo ( isset( $cate['rec_type'] ) && $cate['rec_type'] == 4 ) ? "checked" : ""; ?> />分类推荐栏
								<?php
							}
						?>						
					</td>
				</tr>
				<tr>
					<th colspan="2" > <input type="submit" name="submit" value="更新分类" class="btn" /> </th>					
				</tr>
				<input type="hidden" name="cat_id"
				value="<?php
					if ( !empty( $_REQUEST['cat_id'] ) ) {
						echo $_REQUEST['cat_id'];	
					}
				?>" />
			</table>
		</form>
	</div>	
	
</body>
</html>