<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>文章编辑</title>
    <link rel="stylesheet" href="./css/style.css" />
    <script type="text/javascript" src="../js/jquery.min.js"></script>
    <link rel="stylesheet" href="../plugin/kindeditor/plugins/code/prettify.css" />
    <script charset="utf-8" src="../plugin/kindeditor/kindeditor.js"></script>
    <script charset="utf-8" src="../plugin/kindeditor/lang/zh_CN.js"></script>
    <script charset="utf-8" src="../plugin/kindeditor/plugins/code/prettify.js"></script>
    <script>
        KindEditor.ready(function(K) {
                var editor1 = K.create('textarea[name="content"]', {
                        cssPath : '../plugin/kindeditor/plugins/code/prettify.css',
                        uploadJson : '../plugin/kindeditor/php/upload_json.php',
            fileManagerJson: '../plugin/kindeditor/php/file_manager_json.php',
            allowFileManager: true,
            afterCreate: function() {
                var self = this;
                K.ctrl(document, 13, function() {
                    self.sync();
                    K('form[name=article_add]')[0].submit();
                });
                K.ctrl(self.edit.doc, 13, function() {
                    self.sync();
                    K('form[name=article_add]')[0].submit();
                });
            }
        });
        prettyPrint();
    });
</script>
</head>
<body>
    <?php
        require( "init.php" );
        require( "admin_header.php" );
    ?>

    <?php

        if ( isset( $_POST['submit'] ) ) {
            $title = htmlspecialchars( trim( $_POST['title'] ), ENT_QUOTES  );
            $author = trim( $_POST['author'] );
            $rec_to_index = $_POST['rec_to_index'];
            $is_hot = $_POST['is_hot'];
            $content = htmlspecialchars( trim( $_POST['content'] ), ENT_QUOTES  );
            $is_show = $_POST['is_show'];
            $cat_id = $_POST['cate_list'];
            $sort_order = $_POST['sort'];
            $id = $_REQUEST['id'];

            if ( !empty( $_FILES['img_upload']['tmp_name'] ) ) {
                if ( $_FILES['img_upload']['error'] > 0 ) {
                    switch ( $_FILES['img_upload']['error'] ) {
                        case 1:
                            die( "上传的文件超过了 php.ini 中 upload_max_filesize 选项限制的值" );
                        case 2:
                            die( "上传文件的大小超过了 HTML 表单中 MAX_FILE_SIZE 选项指定的值" );
                        case 3:
                            die( "文件只有部分被上传" );
                        case 4:
                            die( "没有文件被上传" );
                        default:
                            die( "未知错误" );
                    }
                }

                $root_path = str_replace( '\\', '/', dirname( __FILE__ ) );
                $root_path = str_replace( strrchr( $root_path, '/' ), '', $root_path );
                $upload_dir = $root_path . '/upload/';
                if ( upload_file( $_FILES['img_upload']['tmp_name'],
                    $_FILES['img_upload']['name'], $upload_dir  ) ) {

                    $file_name = $upload_dir . $_FILES['img_upload']['name'];
                    $db_file_name = '/upload/' . $_FILES['img_upload']['name'];
                    $dst_img = explode( ".", $_FILES['img_upload']['name'] );
                    // $dst_img_center = $upload_dir . $dst_img[0] . '_center.' . $dst_img[1];
                    // $db_img_center = '/upload/' . $dst_img[0] . '_center.' . $dst_img[1];
                    $dst_img_thumb = $upload_dir . $dst_img[0] . '_thumb.' . $dst_img[1];
                    $db_img_thumb = '/upload/' . $dst_img[0] . '_thumb.' . $dst_img[1];
                    list( $width, $height, $type, $attr ) = getimagesize( $file_name );
                    // zoom_img( $file_name, $dst_img_center, 980, 400  );
                    zoom_img( $file_name, $dst_img_thumb, $width, $height );
                    ?>
                    <script>
                    $( "#tips" ).html( "<span class='success'>文件上传成功</span>" );
                    </script>
                    <?php
                } else {
                    ?>
                    <script>
                    $( "#tips" ).html( "<span class='error'>文件上传失败!</span>" );
                    </script>
                    <?php
                }
            }
            
            $article = get_article_byid( $_REQUEST['id'] );

            $db_file_name = !empty( $db_file_name ) ? $db_file_name : '';
            $db_img_thumb = !empty( $db_img_thumb ) ? $db_img_thumb : $article['feature_img'];

            $cur_time = date( "Y-m-d H:i:s", time() );

            // $sql = "INSERT INTO wm_article( cat_id, title, content, 
            // author, publish_time, is_show, sort_order, rec_to_index, is_hot, feature_img )
            // VALUES ( '$cat_id', '$title', '$content', '$author', '$cur_time', 
            // '$is_show', '$sort_order', '$rec_to_index', '$is_hot', '$db_img_thumb' )";
            
            $sql = "UPDATE wm_article SET cat_id = '{$cat_id}',
            title = '{$title}', content = '{$content}',
            author = '{$author}', publish_time = '{$cur_time}',
            is_show = '{$is_show}', sort_order = '{$sort_order}',
            rec_to_index = '{$rec_to_index}', is_hot = '{$is_hot}',
            feature_img = '{$db_img_thumb}' WHERE article_id = $id";
            
            $res = mysql_query( $sql ) or die ( mysql_error() );
            if ( $res ) {
                echo "<script>alert('更新文章成功!!!');</script>";
            }
        }
    ?>

    <?php
        $root_path = str_replace( '\\', '/', $_SERVER['SCRIPT_NAME'] );
        $root_path = str_replace( strrchr( $root_path, '/' ), '', $root_path );
        $root_path = str_replace( strrchr( $root_path, '/' ), '', $root_path );
        if ( !empty( $_REQUEST['id'] ) ) {
            $article = get_article_byid( $_REQUEST['id'] );
        }
    ?>
    <div class="layout">
        <div id="tips"></div>
        <form action="" method="post" enctype="multipart/form-data" name="article_add">
            <table class="tb w100">
                <tr>
                    <th colspan="2">文章编辑</th>
                </tr>
                <tr>
                    <th>文章标题</th>
                    <td>
                        <input type="text" name="title" size=50 
                        value="<?php if( !empty( $article ) ) {
                                echo htmlspecialchars_decode( $article['title'], ENT_QUOTES );
                            } ?>"/>
                    </td>
                </tr>
                <tr>
                    <th>作者</th>
                    <td>
                        <input type="text" name="author" 
                        value="<?php if( !empty( $article ) ){
                            echo $article['author'];
                            } ?>"/>
                    </td>
                </tr>
                <tr>
                    <th>分类</th>
                    <td>
                        <?php 
                        if ( !empty( $article['cat_id'] ) ) {
                            echo display_cate( 0, $article['cat_id'] );
                        }                        
                        ?>
                    </td>
                </tr>
                <tr>
                    <th>是否推荐到首页</th>
                    <td>
                        <?php
                            if ( !empty( $article ) ) {
                                ?>
                                <input type="radio" name="rec_to_index" value=1 <?php if ( $article['rec_to_index'] == 1 ) { ?>checked <?php } ?> />是
                                <input type="radio" name="rec_to_index" value=0 <?php if ( $article['rec_to_index'] == 0 ) { ?>checked <?php } ?> />否
                                <?php
                            } else {
                                ?>
                                <input type="radio" name="rec_to_index" value=1 checked />是
                                <input type="radio" name="rec_to_index" value=0 />否
                                <?php
                            }
                        ?>                        
                    </td>
                </tr>  
                <tr>
                    <th>是否热点</th>
                    <td>
                        <?php
                            if ( !empty( $article ) ) {
                                ?>
                                <input type="radio" name="is_hot" value=1 <?php if ( $article['is_hot'] == 1 ) { ?>checked <?php } ?> />是
                                <input type="radio" name="is_hot" value=0 <?php if ( $article['is_hot'] == 0 ) { ?>checked <?php } ?> />否
                                <?php
                            } else {
                                ?>
                                <input type="radio" name="is_hot" value=1 checked />是
                                <input type="radio" name="is_hot" value=0 />否
                                <?php
                            }
                        ?>     
                    </td>
                </tr>
                <tr>
                    <th>内容</th>
                    <td>
                        <textarea name="content" style="width:400px;height:300px;visibility:hidden;">
                        <?php
                            if ( !empty( $article ) ) {
                                echo $article['content'];
                            }
                        ?>
                        </textarea>
                    </td>
                </tr>          
                <tr>
                    <th>排序:</th>
                    <td>
                        <input type="text" name="sort" id="sort" 
                        value="<?php if ( !empty( $article ) ) {
                                echo $article['sort_order'];
                            } ?>" />
                    </td>
                </tr>
                <tr>
                    <th>是否显示:</th>
                    <td>
                        <?php
                            if ( !empty( $article ) ) {
                                ?>
                                <input type="radio" name="is_show" value=1 <?php if ( $article['is_show'] == 1 ) { ?>checked <?php } ?> />是
                                <input type="radio" name="is_show" value=0 <?php if ( $article['is_show'] == 0 ) { ?>checked <?php } ?> />否
                                <?php
                            } else {
                                ?>
                                <input type="radio" name="is_show" value=1 checked />是
                                <input type="radio" name="is_show" value=0 />否
                                <?php
                            }
                        ?>    
                    </td>
                </tr>
                <tr>
                    <th>已上传图片:</th>
                    <td>
                        <img 
                        src="<?php                        
                        if ( !empty( $article ) ) {
                            echo $root_path . $article['feature_img'];
                        }    
                         ?>" />                        
                    </td>
                </tr>
                <tr>
                    <th>上传图片:</th>
                    <td>
                        <input type="file" name="img_upload" />
                    </td>
                </tr>
                <input type="hidden" name="id" 
                value="<?php
                    if ( !empty( $article ) ) {
                        echo $article['article_id'];
                    }
                ?>" />
                <tr>
                    <th colspan="2" > <input type="submit" name="submit" value="更新文章" class="btn" /> </th>            
                </tr>
            </table>
        </form>
    </div>  
    
</body>
</html>
