<?php	
	session_start();
	// if ( isset( $_COOKIE['user'] ) && isset( $_COOKIE['password'] ) ) {
	// 	setcookie( 'user', "", time()-1 );
	// 	setcookie( 'password', "", time()-1 );
	// 	header( "Location:./" );
	// }
	
	if ( isset( $_SESSION['admin_user'] ) && isset( $_SESSION['admin_password'] ) ) {
		$_SESSION = array();
		session_destroy();
		header( "Location:./" );
	}
?>