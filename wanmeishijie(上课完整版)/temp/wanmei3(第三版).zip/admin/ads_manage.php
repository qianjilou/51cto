<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>首页轮播广告管理</title>
	<link rel="stylesheet" href="./css/style.css" />
	<script type="text/javascript" src="../js/jquery.min.js"></script>
</head>
<body>
	<?php
		require( "init.php" );
		require( "admin_header.php" );
	?>
	<div class="layout">
		<div id="tips"></div>		
			<table class="tb w100">
				<tr>
					<th colspan="6">首页轮播广告管理</th>
				</tr>
				<tr>
					<th>广告ID</th>
					<th>缩略图</th>
					<th>是否显示</th>
					<th>排序</th>
					<th>链接</th>
					<th>操作</th>
				</tr>
				<?php
					$all_ads = get_all_ads();
					$file_path = str_replace( strrchr( $_SERVER['SCRIPT_NAME'], '/' ), '', 
						$_SERVER['SCRIPT_NAME'] );
					$file_path = str_replace( strrchr( $file_path, '/' ), '', $file_path );
					if ( !empty( $all_ads ) ) {
						foreach ( $all_ads as $ad ) {
							?>
							<tr>
								<td><?php echo $ad['ads_id']; ?></td>
								<td><a href="<?php echo $file_path . $ad['ads_img']; ?>" target="_blank"><img src="<?php echo $file_path . $ad['ads_thumb_img']; ?>" width=210 height=120  /></a></td>
								<td><?php echo ( $ad['is_show'] > 0 ) ? "是" : "否"; ?></td>
								<td><?php echo $ad['sort_order']; ?></td>
								<td><a href="<?php echo $ad['url']; ?>" target="_blank"><?php echo $ad['url']; ?></a></td>
								<td>
									<a href="ads_add.php">添加</a>
									<a href="ads_edit.php?id=<?php echo $ad['ads_id']; ?>">编辑</a>
									<a href="ads_manage.php?act=del&id=<?php echo $ad['ads_id']; ?>">删除</a>
								</td>
							</tr>
							<?php
						}
					}
				?>				
			</table>		
	</div>		
</body>
</html>