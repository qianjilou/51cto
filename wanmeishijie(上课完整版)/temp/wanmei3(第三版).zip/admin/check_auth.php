<?php
	// if ( !empty( $_COOKIE['user'] ) && !empty( $_COOKIE['password'] ) ) {
	// 	if ( !login( $_COOKIE['user'], $_COOKIE['password'] ) ) {
	// 		header( "Location:index.php" );
	// 	}
	// } else {
	// 	header( "Location:index.php" );
	// }
	

	if ( !empty( $_SESSION['admin_user'] ) && !empty( $_SESSION['admin_password'] ) ) {
		if ( !login( $_SESSION['admin_user'], $_SESSION['admin_password'] ) ) {
			header( "Location:index.php" );
		}
	} else {
		header( "Location:index.php" );
	}
?>