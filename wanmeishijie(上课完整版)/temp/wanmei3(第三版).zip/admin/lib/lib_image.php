<?php
	function zoom_img ( $src_img, $dst_img, $dst_width, $dst_height ) {
		$types = array( 1 => 'gif', 2 => 'jpeg', 3 => 'png' );
		list( $width_src, $height_src, $type, $attr ) = getimagesize( $src_img );
		$createfrom = 'imagecreatefrom' . $types[$type];
		$output = 'image' . $types[$type];
		$im_src = $createfrom( $src_img );
		$im_dst = imagecreatetruecolor( $dst_width, $dst_height );
		$copy_result = imagecopyresampled ( $im_dst , $im_src , 
			0 , 0 , 0 , 0 ,
		 	$dst_width , $dst_height , $width_src , $height_src );
		if ( !$copy_result ) {
			die( $src_img . " 图片缩放失败!" );
		}		
		$output( $im_dst, $dst_img );
		imagedestroy( $im_src );
		imagedestroy( $im_dst );
	}

	function crop_img ( $src_img, $dst_img, $src_x, $src_y ) {
		$im_src = imagecreatefromjpeg( $src_img );
		list( $width_src, $height_src, $type, $attr ) = getimagesize( $src_img );
		$im_dst = imagecreatetruecolor( $width_src / 2, $height_src / 2 );
		$copy_result = imagecopyresampled ( $im_dst , $im_src , 
			0 , 0 , $src_x , $src_y ,
		 	$width_src / 2 , $height_src / 2 , $width_src / 2 , $height_src / 2 );
		if ( !$copy_result ) {
			die( $src_img . " 图片裁剪失败!" );
		}
		// header( "Content-type: image/jpeg" );
		imagejpeg( $im_dst, $dst_img );
		imagedestroy( $im_src );
		imagedestroy( $im_dst );
	}

	function upload_file ( $temp_file_name, $file_name, $upload_dir ) {
		$file_type_allow = array( "gif", "jpeg", "png", "jpg" );
		$file_names = explode( ".", $file_name );
		if ( !in_array( strtolower( array_pop( $file_names ) ), $file_type_allow ) ) {
			die( "不支持的文件类型" );
		}
		if ( !is_dir( $upload_dir ) ) {
			mkdir( $upload_dir );
		}
		if ( move_uploaded_file( $temp_file_name, 
			$upload_dir . $file_name ) ) {
			return true;
		} else {
			return false;
		}
	}

	function add_text_watermark ( $file_name, $url, $pos ) {		
		$type_arr = array( 1 => 'gif', 2 => 'jpeg', 3 => 'png' );
		list ( $width, $height, $type, $attr ) = getimagesize( $file_name );		
		$createfrom = "imagecreatefrom" . $type_arr[$type];
		$im = $createfrom( $file_name );		
		$im2 = imagecreatetruecolor( $width, $height );
		$text_color = imagecolorallocate( $im2, 255, 0, 0 );
		$char_width = imagefontwidth( 5 );
		$char_height = imagefontheight( 5 );
		$char_len = strlen( $url ) * $char_width;
		if ( $pos == 'CENTER' ) {
			$cx = ( $width - $char_len ) / 2;
			$cy = ( $height - $char_height ) / 2;	
		} else if ( $pos == 'RIGHT_BOTTOM' ) {
			$cx = $width - $char_len;
			$cy = $height - $char_height;
		}		
		imagestring( $im, 5, $cx, $cy, $url, $text_color );
		header( "Content-type: image/" . $type_arr[$type] );
		$image = "image" . $type_arr[$type];
		$image( $im );
		imagedestroy( $im );
		imagedestroy( $im2 );
	}

	function add_img_watermark ( $watermark_img, $dst_img ) {
		list( $src_width, $src_height, $src_type, $src_attr ) = getimagesize( $watermark_img );
		list( $dst_width, $dst_height, $dst_type, $dst_attr ) = getimagesize( $dst_img );
		$dst_im = imagecreatefromjpeg( $dst_img );
		$src_im = imagecreatefrompng( $watermark_img );
		$dst_x = mt_rand( 0, $dst_width - $src_width );
		$dst_y = mt_rand( 0, $dst_height - $src_height );
		$copyresult = imagecopy ( $dst_im , $src_im , 
			$dst_x , $dst_y , 0 , 0 , 
			$src_width , $src_height );
		if ( !$copyresult ) {
			die( $dst_img . "水印添加失败" );
		}
		imagejpeg( $dst_im, $dst_img );
		imagedestroy( $dst_im );
		imagedestroy( $src_im );
	}
?>