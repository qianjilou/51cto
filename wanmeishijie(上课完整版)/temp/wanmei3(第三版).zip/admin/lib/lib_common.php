<?php	
	function get_cate_list ( $pid = 0, &$result = array(), $space = 0, $type = 0 ) {
		$space += 4;
		$sql = "SELECT * FROM wm_category WHERE pid = $pid";
		$rs = mysql_query( $sql );
		while ( $row = mysql_fetch_assoc( $rs ) ) {
			if ( $type == 0 ) {
				$row['cate_name'] = str_repeat( '&nbsp;', $space ) . '|--' . $row['cate_name'];
			}			
			$result[] = $row;
			if ( $row )  {
				if ( $type != 0 ) {
					get_cate_list( $row['cat_id'], $result[count($result) - 1]['son'], $space, $type );
				} else {
					get_cate_list( $row['cat_id'], $result, $space );
				}
			}
		}
		return $result;
	}	

	function display_cate ( $pid = 0, $selected = '' ) {
		$cate_list = get_cate_list( $pid );
		$s = '';
		$s .= "<select name='cate_list'>";
		$s .= "<option value='0'>根类</option>";
		foreach( $cate_list as $k => $cate ) {
			$sel = '';
			if ( $selected == $cate['cat_id'] ) {
				$sel = 'selected';
			}
			$s .= "<option value = '{$cate['cat_id']}' {$sel} >{$cate['cate_name']}</option>";
		}
		$s .= "</select>";
		return $s;
	}

	function get_cate_path ( $cid, &$result = array() ) {
		$sql = "SELECT * FROM wm_category WHERE cat_id = $cid";
		$rs = mysql_query( $sql );
		$row = mysql_fetch_assoc( $rs );
		$result[] = $row;
		if ( $row['pid'] ) {
			get_cate_path( $row['pid'], $result );
		}
		return $result;
	}
	
	function display_cate_path( $cid ) {
		$cate_path = get_cate_path( $cid );
		krsort( $cate_path );
		$s = '';		
		foreach ( $cate_path as $key => $c_path ) {			
			$s .= "<a href='category.php?cid={$c_path['cat_id']}'>" . $c_path['cate_name'] . "</a>" . ' > ';
		}		
		return substr( $s, 0, strrpos( $s, ' > ' ) - strlen( $s ) );
	}

	function has_category ( $cate_name ) {
		$sql = "SELECT * FROM wm_category WHERE cate_name = '$cate_name'";
		$res = mysql_query( $sql );
		return mysql_num_rows( $res );
	}

	function get_all_ads () {
		$sql = "SELECT * FROM wm_index_ads ORDER BY sort_order ASC";
		$res = mysql_query( $sql );
		$ads = array();
		while ( $row = mysql_fetch_assoc( $res ) ) {
			$ads[] = $row;
		}
		return $ads;
	}

	function get_ads_byid ( $ads_id ) {
		$sql = "SELECT * FROM wm_index_ads WHERE ads_id = $ads_id";
		$res = mysql_query( $sql );
		return mysql_fetch_assoc( $res );
	}

	function get_article_list () {
		$sql = "SELECT a.`article_id`,a.`cat_id`,a.`title`,
		a.`is_show`,a.`publish_time`,a.`sort_order`,c.`cate_name` 
		FROM wm_article a LEFT JOIN wm_category c ON a.`cat_id` = c.`cat_id`";
		$res = mysql_query( $sql );
		$articles = array();
		while ( $row = mysql_fetch_assoc( $res ) ) {
			$articles[] = $row;
		}
		return $articles;
	}

	function get_article_byid ( $id ) {
		$sql = "SELECT * FROM wm_article WHERE article_id = $id";
		$res = mysql_query( $sql );
		return mysql_fetch_assoc( $res );
	}

	function get_cate_byid ( $id ) {
		$sql = "SELECT * FROM wm_category WHERE cat_id = $id";
		$res = mysql_query( $sql );
		return mysql_fetch_assoc( $res );
	}
?>