<?php
	function login ( $user_name, $user_password ) {
		$sql = "SELECT * FROM admin WHERE admin_name = '$user_name' AND admin_password = '$user_password'";
		$res = mysql_query( $sql );
		return mysql_num_rows( $res );
	}
?>