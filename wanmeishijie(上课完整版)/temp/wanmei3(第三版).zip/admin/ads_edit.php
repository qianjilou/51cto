<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>首页轮播广告编辑</title>
	<link rel="stylesheet" href="./css/style.css" />
	<script type="text/javascript" src="../js/jquery.min.js"></script>
</head>
<body>
	<?php
		require( "init.php" );
		require( "admin_header.php" );
	?>
	<?php
		$file_path = str_replace( strrchr( $_SERVER['SCRIPT_NAME'], '/' ), '', 
		$_SERVER['SCRIPT_NAME'] );
		$file_path = str_replace( strrchr( $file_path, '/' ), '', $file_path );
	?>

	<?php

		if ( isset( $_POST['submit'] ) ) {
			$sort = $_POST['sort'];
			$is_show = $_POST['is_show'];
			$url = trim( $_POST['url'] );
			$ads_id = $_REQUEST['id'];

			if ( !empty( $_FILES['img_upload']['tmp_name'] ) ) {
				if ( $_FILES['img_upload']['error'] > 0 ) {
					switch ( $_FILES['img_upload']['error'] ) {
						case 1:
							die( "上传的文件超过了 php.ini 中 upload_max_filesize 选项限制的值" );
						case 2:
							die( "上传文件的大小超过了 HTML 表单中 MAX_FILE_SIZE 选项指定的值" );
						case 3:
							die( "文件只有部分被上传" );
						case 4:
							die( "没有文件被上传" );
						default:
							die( "未知错误" );
					}
				}

				$root_path = str_replace( '\\', '/', dirname( __FILE__ ) );
				$root_path = str_replace( strrchr( $root_path, '/' ), '', $root_path );
				$upload_dir = $root_path . '/upload/';
				if ( upload_file( $_FILES['img_upload']['tmp_name'],
					$_FILES['img_upload']['name'], $upload_dir  ) ) {

					$file_name = $upload_dir . $_FILES['img_upload']['name'];
					$db_file_name = '/upload/' . $_FILES['img_upload']['name'];
					$dst_img = explode( ".", $_FILES['img_upload']['name'] );
					$dst_img_center = $upload_dir . $dst_img[0] . '_center.' . $dst_img[1];
					$db_img_center = '/upload/' . $dst_img[0] . '_center.' . $dst_img[1];
					$dst_img_thumb = $upload_dir . $dst_img[0] . '_thumb.' . $dst_img[1];
					$db_img_thumb = '/upload/' . $dst_img[0] . '_thumb.' . $dst_img[1];
					list( $width, $height, $type, $attr ) = getimagesize( $file_name );
					zoom_img( $file_name, $dst_img_center, 980, 400  );
					zoom_img( $file_name, $dst_img_thumb, $width / 4, $height / 4  );
					?>
					<script>
					$( "#tips" ).html( "<span class='success'>文件上传成功</span>" );
					</script>
					<?php
				} else {
					?>
					<script>
					$( "#tips" ).html( "<span class='error'>文件上传失败!</span>" );
					</script>
					<?php
				}
			}
			
			$ads = get_ads_byid( $_REQUEST['id'] );
			$db_file_name = !empty( $db_file_name ) ? $db_file_name : $ads['ads_ori_img'];
			$db_img_thumb = !empty( $db_img_thumb ) ? $db_img_thumb : $ads['ads_thumb_img'];
			$db_img_center = !empty( $db_img_center ) ? $db_img_center : $ads['ads_img'];

			$sql = "UPDATE wm_index_ads SET ads_img = '$db_img_center', is_show = '$is_show', sort_order = '$sort',
			url = '$url', ads_ori_img = '$db_file_name', ads_thumb_img = '$db_img_thumb' WHERE ads_id = {$ads['ads_id']} ";
			
			$res = mysql_query( $sql ) or die ( mysql_error() );
			if ( $res ) {
				echo "<script>alert('更新成功!!!');</script>";
			}
		}
	?>

	<?php

		if ( isset( $_REQUEST['id'] ) ) {
			$ads = get_ads_byid( $_REQUEST['id'] );
		}
	?>
	<div class="layout">
		<div id="tips"></div>
		<form action="" method="post" enctype="multipart/form-data">
			<table class="tb w100">
				<tr>
					<th colspan="2">首页轮播广告添加</th>
				</tr>				
				<tr>
					<th>排序:</th>
					<td>
						<input type="text" name="sort" id="sort" 
						value="<?php
						if( isset( $ads['sort_order'] ) ) {
							echo $ads['sort_order'];
						}
						?>" />
					</td>
				</tr>
				<tr>
					<th>是否显示:</th>
					<td>
						<?php
							if ( isset( $ads['is_show'] ) && ( $ads['is_show'] == 1 ) ) {
								?>
								<input type="radio" name="is_show" value=1 checked />是
								<input type="radio" name="is_show" value=0 />否
								<?php
							} else {
								?>
								<input type="radio" name="is_show" value=1 />是
								<input type="radio" name="is_show" value=0 checked />否
								<?php
							}
						?>
						
					</td>
				</tr>
				<tr>
					<th>图片</th>
					<td>
					<?php 
						if( !empty( $ads['ads_img'] ) ) {
							?>
							<a href="<?php echo $file_path . $ads['ads_img']; ?>">
								<img width=490 height=200 src="<?php echo $file_path . $ads['ads_img']; ?>" />
							</a>
							<?php
						}
					?>
					</td>
				</tr>
				<tr>
					<th>上传图片:</th>
					<td>
						<input type="file" name="img_upload" />
					</td>
				</tr>
				<tr>
					<th>链接:</th>
					<td>						
						<input type="text" name="url" 
						value="<?php
						if ( !empty( $ads['url'] ) ) {
							echo $ads['url'];
						}
						?>"/>
					</td>
				</tr>
				<input type="hidden" name="id" value="
				<?php 
					if ( !empty( $ads['ads_id'] ) ) {
						echo $ads['ads_id'];
					}
				?>
				" />
				<tr>
					<th colspan="2" > <input type="submit" name="submit" value="更新" class="btn" /> </th>			
				</tr>
			</table>
		</form>
	</div>	
</body>
</html>