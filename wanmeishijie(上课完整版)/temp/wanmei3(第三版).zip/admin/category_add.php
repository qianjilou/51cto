<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>分类添加</title>
	<link rel="stylesheet" href="./css/style.css" />
	<script type="text/javascript" src="../js/jquery.min.js"></script>
</head>
<body>
	<?php
		require( "init.php" );
		require( "admin_header.php" );
	?>
	<div class="layout">
		<div id="tips"></div>
		<form action="" method="post" enctype="multipart/form-data">
			<table class="tb w100">
				<tr>
					<th colspan="2">分类添加</th>
				</tr>
				<tr>
					<th>分类名称:</th>
					<td><input type="text" name="cat_name" id="cat_name" /></td>
				</tr>
				<tr>
					<th>分类列表:</th>
					<td>
						<?php echo display_cate(); ?>						
					</td>
				</tr>
				<tr>
					<th>关键词:</th>
					<td>
						<textarea name="keywords" id="keywords" cols="50" rows="3"></textarea>
					</td>
				</tr>
				<tr>
					<th>描述:</th>
					<td>
						<textarea name="desc" id="desc" cols="50" rows="10"></textarea>
					</td>
				</tr>
				<tr>
					<th>排序:</th>
					<td>
						<input type="text" name="sort" id="sort" value="100" />
					</td>
				</tr>
				<tr>
					<th>是否显示:</th>
					<td>
						<input type="radio" name="is_show" value=1 checked />是
						<input type="radio" name="is_show" value=0 />否
					</td>
				</tr>
				<tr>
					<th>上传图片:</th>
					<td>
						<input type="file" name="img_upload" />
					</td>
				</tr>
				<tr>
					<th>链接:</th>
					<td>						
						<input type="text" name="url" />
					</td>
				</tr>
				<tr>
					<th>分类类型:</th>
					<td>
						<input type="radio" name="type[]" value="1" checked />分类
						<input type="radio" name="type[]" value="2" />文章
						<input type="radio" name="type[]" value="3" />政策
						<input type="radio" name="type[]" value="4" />导航栏
					</td>
				</tr>
				<tr>
					<th>推荐:</th>
					<td>
						<input type="radio" name="rec_type[]" value="0" checked />无
						<input type="radio" name="rec_type[]" value="1" />热门
						<input type="radio" name="rec_type[]" value="2" />最新
					</td>
				</tr>
				<tr>
					<th colspan="2" > <input type="submit" name="submit" value="添加分类" class="btn" /> </th>					
				</tr>
			</table>
		</form>
	</div>	
	<?php
		if ( isset( $_POST['submit'] ) ) {
			$cat_name = trim( $_POST['cat_name'] );
			if ( has_category( $cat_name ) ) {
				echo "<script>alert('分类名已经存在!!!');</script>";
				die();
			}
			$pid = $_POST['cate_list'];
			if ( empty( $cat_name ) ) {
				echo "<script>alert('分类名没有填写!!!');</script>";
				die();
			}
			$keywords= trim( $_POST['keywords'] );
			$desc = trim( $_POST['desc'] );
			$sort = $_POST['sort'];
			$is_show = $_POST['is_show'];
			$url = $_POST['url'];
			$type = $_POST['type'][0];
			$rec_type = $_POST['rec_type'][0];

			if ( !empty( $_FILES['img_upload']['tmp_name'] ) ) {
				if ( $_FILES['img_upload']['error'] > 0 ) {
					switch ( $_FILES['img_upload']['error'] ) {
						case 1:
							die( "上传的文件超过了 php.ini 中 upload_max_filesize 选项限制的值" );
						case 2:
							die( "上传文件的大小超过了 HTML 表单中 MAX_FILE_SIZE 选项指定的值" );
						case 3:
							die( "文件只有部分被上传" );
						case 4:
							die( "没有文件被上传" );
						default:
							die( "未知错误" );
					}
				}

				$root_path = str_replace( '\\', '/', dirname( __FILE__ ) );
				$root_path = str_replace( strrchr( $root_path, '/' ), '', $root_path );			
				$upload_dir = $root_path . '/upload/';
				if ( upload_file( $_FILES['img_upload']['tmp_name'],
					$_FILES['img_upload']['name'], $upload_dir  ) ) {

					$file_name = $upload_dir . $_FILES['img_upload']['name'];
					$db_file_name = '/upload/' . $_FILES['img_upload']['name'];
					$dst_img = explode( ".", $_FILES['img_upload']['name'] );
					$dst_img_center = $upload_dir . $dst_img[0] . '_center.' . $dst_img[1];
					$db_img_center = '/upload/' . $dst_img[0] . '_center.' . $dst_img[1];
					$dst_img_thumb = $upload_dir . $dst_img[0] . '_thumb.' . $dst_img[1];
					$db_img_thumb = '/upload/' . $dst_img[0] . '_thumb.' . $dst_img[1];
					list( $width, $height, $type, $attr ) = getimagesize( $file_name );
					zoom_img( $file_name, $dst_img_center, $width / 2, $height / 2  );
					zoom_img( $file_name, $dst_img_thumb, $width / 4, $height / 4  );
					?>
					<script>
					$( "#tips" ).html( "<span class='success'>文件上传成功</span>" );
					</script>
					<?php
				} else {
					?>
					<script>
					$( "#tips" ).html( "<span class='error'>文件上传失败!</span>" );
					</script>
					<?php
				}
			}
			
			$db_file_name = !empty( $db_file_name ) ? $db_file_name : '';
			$db_img_thumb = !empty( $db_img_thumb ) ? $db_img_thumb : '';
			$db_img_center = !empty( $db_img_center ) ? $db_img_center : '';

			$sql = "INSERT INTO wm_category( cate_name, keywords, `desc`, pid, sort_order,
			is_show, img_center, img_thumb, img_original, center_url, thumb_url, original_url, type, rec_type )
			VALUES ( '$cat_name', '$keywords', '$desc', '$pid', '$sort', '$is_show',
			'$db_img_center', '$db_img_thumb', '$db_file_name', '$url', '$url', '$url', '$type', '$rec_type' )";
			$res = mysql_query( $sql ) or die ( mysql_error() );
			echo "<script>alert('分类添加成功!!!');</script>";			
		}
	?>
</body>
</html>